import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
const LotsOfStyles = () => {
    return (
      <View style={styles.container}>
      <Text style={styles.link}
      onPress={() => Linking.openURL('http://brightmagazine.ru/')}>
  Новости
</Text>
        <Image
        style={styles.logo}
        source={{
          uri: 'http://brightmagazine.ru/wp-content/uploads/2020/12/pexels-andrea-piacquadio-3755761-600x400.jpg',
        }}
      />
        <Text style={styles.bigBlack}>Превращаем стресс в своего помошника</Text>
        <Text style={[styles.black]}>Исследователи Йельского университета заявляют, что люди, которые рассматривают стресс, как возможность личностного роста, отмечают улучшение качества жизни. Сегодня узнаем, как это работает и как увидеть положительные стороны стресса.</Text>
      </View>
    );
};
const styles = StyleSheet.create({
  container: {
    marginTop: 40,
    marginLeft:30,
    marginRight:30,
  },
  link: {
    color: 'blue',
  },
  bigBlack: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: 30,
    marginTop: 20,
  },
  black: {
    marginTop: 20,
    color: 'black',
  },
  logo: {
    width: 350,
    height: 150,
    marginTop: 40,
  },
});
export default LotsOfStyles;
