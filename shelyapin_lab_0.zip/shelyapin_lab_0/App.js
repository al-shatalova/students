import React from 'react';
import {Text, View} from 'react-native';

const YourApp = () => {
  return(
    <View style = {{flex: 1, justifyContent:"center", alignItems:"center"}}>
    <Text>
      Shot on Iphone
    </Text>
    </View>
  );
}

export default YourApp;