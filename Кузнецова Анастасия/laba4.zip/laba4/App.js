import * as React from 'react';
import { TextInput,Alert,Button, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

const Stack = createStackNavigator();

const Separator = () => (
  <View style={styles.sep} />
);

export default function MyStack(){
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
        name='Ответ: соль'
        component={home}
        />
        <Stack.Screen name="Ответ: волнушки" component={second}/>
        <Stack.Screen name="Ответ: санки" component={third} />
      </Stack.Navigator>
    </NavigationContainer>)}

const home = ({ navigation }) => {
  return (
    <View style={styles.container1}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        В воде родится, воды боится.
        <Separator />
      </Text>
        <Button
        color = '#ee82ee'
        title="Перейти к следующей загадки"
        onPress={() => navigation.navigate('Ответ: волнушки')
      }
      />
    </View>
  </View>
  );
}

const second = ({ navigation }) => {
  return (
    <View style={styles.container2}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        Растут на опушке
рыжие подружки,
Их зовут …
      </Text>
      <Button
        color = '#FFFF00'
        title="Перейти к следующей загадки"
        onPress={() => navigation.navigate('Ответ: санки')
        }
      />
      </View>
    </View>
    );
}
  const third = ({ navigation }) => {
    return (
    <View style={styles.container3}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        Вот полозья, спинка, планки –
А всё вместе это – ...
      </Text>
      <Button
        color = '#FF0000'
        title="Вернуться назад?"
        onPress={() => navigation.navigate('Ответ: соль')
      }
    />
    </View>
  </View>
  );
}


const styles = StyleSheet.create({
  container1: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#9370db',
    padding: 30,
  },
    container2: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#FFA500',
    padding: 20,
  },
   container3: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#F08080',
    padding: 30,
  },
  paragraph: {
    margin: 50,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    sep: {
    marginVertical: 8,
    borderBottomColor: '#f2e7c9',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  main: {
    backgroundColor: "#f2e7c9",
    borderRadius: 9
  }, 
}
);