import * as React from 'react';
import { TextInput,Alert,Button, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

const Stack = createStackNavigator();

const Separator = () => (
  <View style={styles.sep} />
);

export default function MyStack(){
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
        name='1 Факт о Лионель Месси'
        component={home}
        />
        <Stack.Screen name="2 Факт о Лионель Месси" component={second}/>
        <Stack.Screen name="3 Факт о Лионель Месси" component={third} />
      </Stack.Navigator>
    </NavigationContainer>)}

const home = ({ navigation }) => {
  return (
    <View style={styles.container1}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        В детстве Лионелю диагностировали нарушение гормона роста
        <Separator />
      </Text>
        <Button
        color = '#7B68EE'
        title="Дальше"
        onPress={() => navigation.navigate('2 Факт о Лионель Месси')
      }
      />
    </View>
  </View>
  );
}

const second = ({ navigation }) => {
  return (
    <View style={styles.container2}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        Свой 10 номер в команде он унаследовал от Роналдиньо
      </Text>
      <Button
        color = '#7B68EE'
        title="Дальше"
        onPress={() => navigation.navigate('3 Факт о Лионель Месси')
        }
      />
      </View>
    </View>
    );
}
  const third = ({ navigation }) => {
    return (
    <View style={styles.container3}>
    <View style={styles.main}>
      <Text style={styles.paragraph}>
        Прозвище Месси — «атомная блоха».
      </Text>
      <Button
        color = '#7B68EE'
        title="Начать сначала"
        onPress={() => navigation.navigate('1 Факт о Лионель Месси')
      }
    />
    </View>
  </View>
  );
}


const styles = StyleSheet.create({
  container1: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#B0E0E6',
    padding: 30,
  },
    container2: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#1E90FF',
    padding: 20,
  },
   container3: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#00FFFF',
    padding: 30,
  },
  paragraph: {
    margin: 40,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    sep: {
    marginVertical: 8,
    borderBottomColor: '#FFA07A',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  main: {
    backgroundColor: "#FFA07A",
    borderRadius: 9
  }, 
}
);