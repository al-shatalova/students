import React from 'react';
import {Alert, Image, View, Button, StyleSheet, Text, SafeAreaView, ScrollView } from 'react-native';
import Constants from 'expo-constants';
import {ImageBackground} from "react-native"
const Separator = () => (
  <View style={styles.separator} />
);
const App = () => {
  return (
    <View style={styles.container}>
    <ImageBackground source={require('./picture.jpg')} style={styles.backgroundImage}>
     <Text style={{fontWeight:"bold", color: "white",marginTop:150,fontSize:20, textAlign:"center"}}>
      Вдохновляющие истории трех знаменитых мужчин, которые никогда не сдавались
      </Text>
    </ImageBackground>
    <Separator />
    <View style={styles.main}>
        <Text style={styles.text}>
          Препятствия и сложности встречаются на жизненном пути каждого, но они не должны становиться причиной отказа от мечты и новых свершений. Сегодня мы расскажем вам истории трех знаменитых мужчин, которые до того, как добиться славы, на себе испытали многочисленные трудности и даже нищету. Пусть их истории послужат вдохновением двигаться вперед навстречу мечте. 
        </Text>
        <Button
        title="ЧИТАТЬ ДАЛЕЕ"
        onPress={() => Alert.alert('Simple Button pressed')}
        color="#841584"
      />
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    marginHorizontal: 16,
    flex: 3,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding: 8,
  },
   backgroundImage: {
    flex: 1,
    flexDirection: 'cover', // or 'stretch'
    justifyContent: 'center',
    alignItems: 'center',
    width: null,
    height: null
  },
  text: {
    marginTop: 15,
    marginLeft: 25,
    marginRight: 20,
    marginBottom: 10,
  },
  main: {
    flex:1,
    backgroundColor: "#808080",
    borderRadius: 3
  }, 
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default App;
