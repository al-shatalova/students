import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 3, backgroundColor: 'white' }}>
      <Text style={styles.paragraph}>
        Журнал Bright
      </Text>
      </View>
      <View style={{ flex: 5, backgroundColor: 'lightgrey' }}>
      <Text style={styles.paragraph}>
        Лучшие мини-сериалы для отпускных вечеров
      </Text>
      </View>
      <View style={{ flex: 10, backgroundColor: 'grey' }}>
      <Text style={styles.paragraph}>
        Часто сериалы ассоциируются у нас с долгой историей или циклом историй. Но сейчас также в моде мини-сериалы, которые можно посмотреть полностью всего лишь за один день. Мы собрали для вас лучшие из них, чтобы вы могли насладиться захватывающей историей в отпуске.  
      </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  paragraph: {
    marginTop: 30,
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',

  },
});