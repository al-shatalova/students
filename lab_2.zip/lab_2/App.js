import React from 'react';
import {Image, StyleSheet, Text, View, Button} from 'react-native';

const App = () => {
return (
  <View style={styles.container}>
    <Text style={styles.heading}>5 книжных новинок октября</Text>
  <View style={styles.nestedContainer}>

  <Text style={[styles.news, styles.newsHeader]}>
    Шесть продуктов, которые считаются вредными, а зря
  </Text>
  </View>
  <View style={styles.nestedContainer1}>
  <Text style={[styles.news, styles.newsText]}>
    Тема здорового питания с каждым днем интересует все больше людей, но гипотезы, представленные в СМИ, нередко противоречат друг другу, потому что у большинства продуктов есть как полезные свойства, так и потенциальный вред.
  </Text>
  
  </View>
  <Button title = 'Читать далее'>
      
  </Button>
</View>
);
};

const styles = StyleSheet.create({
  heading: {
    fontWeight: 'bold',
    paddingTop: '10%',
    alignSelf: 'center',
    fontSize: 24,
    paddingBottom: '1%',
  },
  container: {
    backgroundColor: '#white',
    width: '100%',
    height: '100%',
    flex: 1,
  },
  nestedContainer: {
    backgroundColor: 'lightgray',
    width: '100%',
    height: '20%',
    margin: '0%',
    flex: 1,
  },
  nestedContainer1: {
    backgroundColor: 'gray',
    width: '100%',
    height: '80%',
    margin: '0%',
    flex: 1,
  },
  news: {
    paddingStart: '10%',
    paddingTop: '10%',
    paddingEnd: '10%',
  },
  
  newsHeader: {
    fontWeight: 'bold',
    paddingTop: '5%',
    fontSize: 28,
    textAlign: 'center',
  },
 
  newsText: {
    paddingTop: '5%',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default App;
