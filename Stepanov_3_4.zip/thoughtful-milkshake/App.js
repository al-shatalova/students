import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';
import MyNavigator from './navigate/Navigator';

export default function App() {

    return (
      <MyNavigator />
    );

}
