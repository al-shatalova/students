import {createStackNavigator} from 'react-navigation-stack';
import {createAppContainer } from 'react-navigation';

import Launch from '../screens/Launch';
import Welcome from '../screens/Welcome';
import Register from '../screens/Register';

const MyNavigator = createStackNavigator({
     "Launch": {
       screen: Launch,
       navigationOptions: {
         header: null
       }
       },
     "Welcome": {
       screen: Welcome,
       navigationOptions: {
         header: null
       }
       },
     "Register": {
       screen: Register,
       navigationOptions: {
         header: null
       }
       }
});

export default createAppContainer(MyNavigator);