import React, {useState} from 'react';  
import {StyleSheet, Text, Button, View, Image} from 'react-native'; 
import logo from "../img/icon.png";

 const Launch = props => {

  function nav(){
      props.navigation.navigate({routeName: 'Welcome'});
  }
   
 return (  
        <View style={styles.container} onClick={nav}>  
          <Image source={logo} style={styles.logo} />
        </View>  
    );  
  
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
        flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center',
        background: "#9c27b0"
    },  
    logo : {
      width: "128px",
      height: "128px"
    }
});  

export default Launch;


