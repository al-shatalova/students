import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  Button,
  View,
  Image,
  Dimensions
} from 'react-native';
import pic from "../img/screen.png";

const Welcome = (props) => {
  function nav() {
    props.navigation.navigate({ routeName: 'Register' });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Делиться изображениями стало проще</Text>
      <Image source={pic} style={styles.pic} />
      <Text style={styles.about}>Друзья, родственники и просто знакомые увидят вашу насыщенную жизнь</Text>
      <View style={styles.btn}></View>
      <Button buttonStyle={styles.btn} color={'#9c27b0'} onPress={nav} title={'Далее'} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'top',
    alignItems: 'center',
    paddingTop: "30px"
  },
  title: {
    fontWeight: "bold",
    color: "black",
    fontFamily: "Tahoma"
  },
  pic: {
    width: "240px",
    height: "334px",
    marginTop: "35px"
  },
  about: {
    color: "#616161",
    fontFamily: "Tahoma",
    textAlign: "center",
    marginTop: "25px"
  },
  btn: {
    marginTop: "25px",
    width: "100%"
  }
});

export default Welcome;
