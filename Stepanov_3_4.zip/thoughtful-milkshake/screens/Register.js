import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  Button,
  View,
  Image,
  Dimensions,
  TouchableOpacity
} from 'react-native';
import logo from "../img/icon.png"

const Register = (props) => {
  return (
    <View style={styles.container}>
      <Image source={logo} style={styles.logo} />
       <Text style={styles.title}>Теперь пора познакомиться</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
      />
      <TextInput
        style={styles.input2}
        placeholder="Пароль"
      />
      <View style={styles.tab}></View>
      <TouchableOpacity style={styles.btn}>
        <Text style={styles.btnText}>ВОЙТИ В АККАУНТ</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    background: "#9c27b0"
  },
  title: {
    color: "white",
    fontWeight: "bold",
    fontFamily: "Tahoma"
  },
  input: {
    background: "white",
    padding: "10px",
    color: "black",
    fontFamily: "tahoma",
    marginTop: "50px",
    width: "90%",
    borderRadius: "5px"
  },
  input2: {
    background: "white",
    padding: "10px",
    color: "black",
    fontFamily: "tahoma",
    marginTop: "10px",
    width: "90%",
    borderRadius: "5px"
  },
  logo: {
    height: "96px",
    width: "96px",
    marginTop: "25px"
  },
  tab: {
    marginTop: "45px"
  },
  btn: {
    padding: "10px",
    background: "white",
    borderRadius: "5px"
  },
  btnText: {
    fontWeight: "bold",
    color: "#9c27b0"
  }
});

export default Register;
