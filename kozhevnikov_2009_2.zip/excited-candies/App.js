import React from 'react';
import {Text,View } from 'react-native';

const FlexDimensionsBasics = () => {
  return (
    // Try removing the `flex: 1` on the parent View.
    // The parent will not have dimensions, so the children can't expand.
    // What if you add `height: 300` instead of `flex: 1`?
    <View style={{ flex: 1 }}>
      <View style={{ flex: 1, backgroundColor: 'powderblue' }}>
        <Text style={{textAlign: "center", marginTop: 50, fontWeight: "bold"}}>
          5 книжных новинок окрября
        </Text>
      </View>
      <View style={{ flex: 2, backgroundColor: '#D3D3D3' }}>
      <Text style={{textAlign: "center", margin: 20}}>
          Многие считают, что достижение счастья – это усилие, которое длится всю жизнь.  Но ведь счастье уже ждет каждого из нас в каждом моменте, надо только заметить и погрузиться в него. Мы собрали для вас девять привычек, которые помогут почувствовать себя более счастливым.5 книжных новинок окрября
      </Text>
      </View>
     <View style={{ flex: 7, backgroundColor: '#C0C0C0' }}>
      <Text style={{textAlign: "center", margin: 20}}>
      Получить навыки настройки среды для отладки приложений на React
Native.
Задания для выполнения
1
Перейдите на сайт https://snack.expo.io/ и установите на телефон
приложение Expo. Отсканируйте QR-код и синхронизируйте Expo-
редактор и ваше устройство.
2
Используя стрелочную функцию (или класс), задайте компонент,
который выведет на экран вашего устройства Hello World.
3
Загрузить созданную программу на GitHub в репозиторий Student,
используя формат в названии Фамилия (латинскими буквами)_1.
          </Text>
      </View>
      </View>
  );
};

export default FlexDimensionsBasics;

