import React from 'react';
import {Image, StyleSheet, Text, View, Button} from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
    <Text style={styles.heading}>5 Книжных новинок</Text>
      <View style={styles.nestedContainer}>    
      <Text style={[styles.news, styles.newsHeader]}>
  В поисках уединения: самый маленький остров
      </Text>

      <View style = {[styles.nestedContainer2]}>
      <Text style={[styles.news, styles.news]}>
Когда мы произносим словосочетание «маленький обитаемый остров», многие из нас представляют картинку острова с пальмами, белоснежным песком и роскошным отелем.     Но самый маленький обитаемый остров в мире под названием Just Room Enough Island имеет совсем другое очарование.
      </Text>
      
      </View>
      <Button 
      title = "bt1"
      color = "black"
      c
      >


        Активировать лазеры
      </Button>

      </View>
  </View>
  );
};

const styles = StyleSheet.create({
  heading: {
    fontWeight: 'bold',
    paddingTop: '10%',
    alignSelf: 'center',
    fontSize: 24,
    paddingBottom: '1%',
  },
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    width: '100%',
    height: '100%',
  },
  nestedContainer: {
    flex: 1,
    backgroundColor: '#C9C9C9',
    width: '100%',
    height: '80%',
    margin: '0%',
  },
  nestedContainer2: {
    flex: 1,
    backgroundColor: '#878787',
    width: '100%',
    height: '70%',
    margin: '0%',
    
  },
  news: {
    paddingStart: '10%',
    paddingTop: '10%',
    paddingEnd: '10%',
    fontSize: 16
  },
  newsButton: {
    color: 'blue',
    fontSize: 18,
    paddingBottom: '10%',
  },
  newsHeader: {
    fontWeight: 'bold',
    paddingTop: '5%',
    fontSize: 28,
  },
  newsImage: {
    width: '80%',
    alignSelf: 'center',
    height: 200,
  },
  newsText: {
    paddingTop: '5%',
    fontSize: 16,
  },
});

export default App;