import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Журнал Bright
      </Text>
      <Card>
      <Text style={styles.bigBlue}>
        Девять привычек, чтобы почувствовать себя более счастливым
      </Text>
      <Text style={styles.paragraph}>
      Многие считают, что достижение счастья – это усилие, которое длится всю жизнь.  Но ведь счастье уже ждет каждого из нас в каждом моменте, надо только заметить и погрузиться в него. Мы собрали для вас девять привычек, которые помогут почувствовать себя более счастливым.
      </Text>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  bigBlue: {
    margin: 24,
    padding: 8,
    color: 'blue',
    fontWeight: 'bold',
    fontSize: 30,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
