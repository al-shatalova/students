import * as React from 'react';
import { Text, Image, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import logo from "assets/1111.png"


export default function App() {
  return (
    <View style={styles.container}>
      <h4>Журнал Bright</h4>
      <div style={{background:"white", maxWidth:"82vw", width:"82vw", margin:"0 auto",  borderRadius:"5px",  padding:"20px",  textAlign:"left", wordWrap:"break-word", boxShadow: "0 2px 2px -2px gray"}}>
        <div style={{color:"blue", fontSize:"14px", marginTop:"10px"}}>Новости</div>
        <Image source={logo} style={{maxWidth:"90%", maxHeight:"150px", marginTop:"35px"}} />
        <h3 style={{}}>Лучшие мини-сериалы для отпускных вечеров</h3>
        <div style={{fontSize:"13px"}}>
          Часто сериалы ассоциируются у нас с долгой историей или циклом историй. Но сейчас также в моде мини-сериалы, которые можно посмотреть полностью всего лишь за один день. Мы собрали для вас лучшие из них, чтобы вы могли насладиться захватывающей историей в отпуске.  
        </div>
      </div>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    fontFamily: "Tahoma",
    alignItems: "center",
    background: "#eeeeee",
    padding: "5px"
  }
});
