import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';


export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>5 книжных новинок ноября</Text>
      <View style={styles.first}>
        <Text>"Кадиш.com" Натан Ингландер. Издательство "Книжники"</Text>
      </View>
      <View style={styles.second}>
        <Text>Ироничная новелла Натана Ингландера, две личные истории культовой Патти Смит, репортаж британской журналистки о будущем человества, дебютный роман Оушена Вуонга и журналистское расследование о создании "Моссада". В нашей  подборке рассказываем о пяти захватывающих книжных новинках, которые достойны того, чтобы появиться на ваших полках.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "top",
    alignItems: "center",
    paddingTop: "10px",
    fontFamily: "Tahoma"
  },
  header: {
    fontWeight: "bold",
    fontSize: "20px"
  },
  first: {
    flex: 1,
    textAlign: "center",
    padding: "20px",
    background: "#e0e0e0",
    marginTop: "10px"
  },
  second: {
    flex: 4,
    textAlign: "center",
    padding: "20px",
    background: "#9e9e9e",
    fontSize: "13px"
  }
});
