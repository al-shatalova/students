import React from 'react';
import {Image, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import logo from './6EmXYgtu79w.png'

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

const YourApp = () => {
  return (
    <View style = {styles.container}>
    <Text style = {styles.topper}>Журнал bright</Text>
    <Card>
      <Text style = {styles.red}>Журнал, вдохновляющий ставить яркие цели и идти к ним. (18+)</Text>
      <Text style = {styles.bigBlue}>Девять привычек, чтобы почувствовать себя более счастливым </Text>
      <Image source={logo} style={styles.logo} />
      <Text style = {styles.usual}>Коллективная мудрость гласит, что вы можете научиться быть счастливыми, только после того, как научитесь быть счастливыми наедине с собой. Согласны?

А пока вы размышляете над этим, мы подготовили для вас подборку девяти привычек, которые помогут вам вернуть ощущение счастья.

 

Осознать, что у вас есть выбор

Хотя часто мы не можем избежать трудностей, мы все же имеем возможность выбирать, как на них реагировать. Почувствовать себя счастливее поможет осознание, что счастье – это выбор, а не удача, улыбающаяся только избранным.

 

Практика благодарности

Даже в самые трудные времена есть вещи, за которые мы благодарны. Признание всего хорошего, происходящего в жизни, важно для того, чтобы научиться быть счастливым.

</Text>
</Card>
        <Text>Kozhevnikov Nikolay PI18-2</Text>
   </View>
  );
}

export default YourApp;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#DCDCDC',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bigBlue:{
    color:'black',
    fontWeight: 'bold',
    fontSize: 30,
    margin: 20,
    textAlign: 'center',

  },
  red: {
    color: 'blue',
    margin: 20,
  
  },
  usual: {
    padding: 10, /* Поля вокруг текста */
    margin: 10, /* Отступы вокруг */
  },
  topper: {
    textAlign: 'center',
    fontWeight: 'bold',
  },
  logo: {
    alignItems: "center",
    alignContent: "center",
    width: 375,
    height: 100,
  }
});
