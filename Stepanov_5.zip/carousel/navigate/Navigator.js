import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';

import Launch from '../screens/Launch';
import Carousel from '../screens/Carousel';

const MyNavigator = createStackNavigator({
  Launch: {
    screen: Launch,
    navigationOptions: {
      header: null,
    },
  },
  Carousel: {
    screen: Carousel,
    navigationOptions: {
      header: null,
    },
  },
});

export default createAppContainer(MyNavigator);
