import React, { useState, useRef } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  Button,
  View,
  Image,
  Dimensions,
  ScrollView,
  useWindowDimensions,
  SafeAreaView,
  ImageBackground,
  Animated,
} from 'react-native';
import card1 from '../img/1.png';
import card2 from '../img/2.png';
import card3 from '../img/3.png';
import card4 from '../img/4.png';

const images = new Array();
images.push(card1);
images.push(card2);
images.push(card3);
images.push(card4);

const Carousel = (props) => {
  const scrollX = useRef(new Animated.Value(0)).current;
  const { width: windowWidth } = useWindowDimensions();

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Делиться изображениями стало проще</Text>
      <View style={styles.scrollContainer}>
        <ScrollView
          horizontal={true}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Animated.event([
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollX,
                },
              },
            },
          ])}
          scrollEventThrottle={1}>
          {images.map((image, imageIndex) => {
            return (
              <View
                key={imageIndex}
                style={{ width: windowWidth, height: 337 }}>
                <ImageBackground
                  source={image}
                  style={styles.card}></ImageBackground>
              </View>
            );
          })}
        </ScrollView>
      </View>
      <View style={styles.indicatorContainer}>
        {images.map((image, imageIndex) => {
          const width = scrollX.interpolate({
            inputRange: [
              windowWidth * (imageIndex - 1),
              windowWidth * imageIndex,
              windowWidth * (imageIndex + 1),
            ],
            outputRange: [8, 16, 8],
            extrapolate: 'clamp',
          });
          return (
            <Animated.View
              key={imageIndex}
              style={[styles.normalDot, { width }]}
            />
          );
        })}
      </View>
      <Text style={styles.about}>
        Друзья, родственники и просто знакомые увидят вашу насыщенную жизнь
      </Text>
      <View style={styles.btn}></View>
      <Button buttonStyle={styles.btn} color={'#9c27b0'} title={'Далее'} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 70,
  },
  scrollContainer: {
    height: 337,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 25,
    marginBottom: 45,
  },
  title: {
    fontWeight: 'bold',
    color: 'black',
    fontFamily: 'Tahoma',
    fontSize: 18
  },
  about: {
    color: '#616161',
    fontFamily: 'Tahoma',
    textAlign: 'center',
  },
  btn: {
    marginTop: 25,
    width: '100%',
  },
  card: {
     flex: 1,
     marginVertical: 4,
     marginHorizontal: 16,
     borderRadius: 5,
     overflow: 'hidden',
     alignItems: 'center',
     justifyContent: 'center',
     width: 337
  },
  indicatorContainer: {
     marginBottom: 15,
     flexDirection: 'row',
     alignItems: 'center',
     justifyContent: 'center',
  },
  normalDot: {
     height: 8,
     width: 8,
     borderRadius: 4,
     backgroundColor: 'silver',
     marginHorizontal: 4,
  },
});

export default Carousel;
