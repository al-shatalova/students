import React, {useState, useRef} from 'react';  
import {StyleSheet, Text, Button, View, Image, Animated} from 'react-native'; 
import logo from "../img/icon.png"

const FadeInView = (props) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    Animated.timing(
      fadeAnim, {
        toValue: 1,
        duration: 1500
      }
    ).start();
  }, [fadeAnim])

  return (
    <Animated.View style={{...props.style, opacity: fadeAnim}}>
      {props.children}
    </Animated.View>
  )
}

const MoveUpView = (props) => {
  const moveAnim = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    Animated.timing(
      moveAnim, {
        toValue: 100,
        duration: 1500
      }
    ).start();
  }, [moveAnim])

  return (
    <Animated.View style={{...props.style, marginTop: moveAnim}}>
      {props.children}
    </Animated.View>
  )
}

 const Launch = props => {

   React.useEffect(() => {
      setTimeout(() => {props.navigation.navigate({routeName: "Carousel"})}, 2000)
   })
   
 return (  
        <View style={styles.container}>
          <FadeInView>
            <Image source={logo} style={styles.icon} />
          </FadeInView>
          <MoveUpView>
            <Text style={styles.title}>Делиться изображениями</Text>
          </MoveUpView>
        </View>  
    );  
  
}

const styles = StyleSheet.create({
  container: {
    display: "flex",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9c27b0"
  },
  icon: {
     width: 128,
     height: 128
  },
  title: {
    color: "white",
    fontFamily: "Tahoma",
    fontSize: 18
  }
})

export default Launch