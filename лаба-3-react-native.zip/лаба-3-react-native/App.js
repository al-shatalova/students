import React from 'react';
import {Image, View, Button, StyleSheet, Text, SafeAreaView, ScrollView } from 'react-native';
import Constants from 'expo-constants';

const Separator = () => (
  <View style={styles.separator} />
);
const App = () => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.text}>
          In Armenia, Sayat Nova is considered a great poet who made a considerable contribution to the Armenian poetry and music of his century. Although he lived his entire life in a deeply religious society, his works are mostly secular and full of romantic expressionism.

About 220 songs have been attributed to Sayat-Nova, although he may have written thousands more. He wrote his songs in Armenian, Georgian and Persian. Sayat Nova had also written some poems moving between all three.
        </Text>
        <Separator />
        <View style={styles.containeri}>

      <Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Sayat-Nova_1964.jpg/411px-Sayat-Nova_1964.jpg',
        }}
      />

    </View>

        <Button
        title="Press me"
        onPress={() => Alert.alert('Simple Button pressed')}
      />
      </ScrollView>
    </SafeAreaView>

  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },
  scrollView: {
    backgroundColor: '#CEE3FE',
    marginHorizontal: 20,
  },
  text: {
    fontSize: 42,
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },

  containeri: {
    paddingTop: 50,
  },
  tinyLogo: {
    width: 300,
    height: 300,
  },
});

export default App;